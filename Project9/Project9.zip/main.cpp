/*
	Objected Oriented and c++
	Ex 2, 14/01/2020
	Yaniv Yossef, id. 311131932
	Netanel Yerushalmi, id. 311144075
*/

#pragma warning(disable:4996)
#include <iostream>
#include <string.h>
#include "System.h"

using namespace std;


int main()
{
	const char* systemName = "Yaniv commerce store";
	System sys(systemName);
	sys.run();
}
